import sqlite3
import json
import os

flag_add_organization = False
flag_add_request = False

def add_organization(conn, org_name, department, address):
	global flag_add_organization

	c = conn.cursor()
	c.execute('''
		SELECT id_org FROM organization 
		WHERE org_name = ? AND department = ? AND address = ?
	''', (org_name, department, address))

	row = c.fetchone()
	if row:
		id_org = row[0]
		#print(f"Организация уже есть: {org_name}, id={id_org}")
		flag_add_organization = True
		return id_org
	else:
		c.execute('''
			INSERT INTO organization (org_name, department, address)
			VALUES (?, ?, ?)
		''', (org_name, department, address))
		id_org = c.lastrowid
		#print(f"Добавлена новая организация: {org_name}, id={id_org}")
		conn.commit()
		return id_org

def add_request(conn, id_org, request_number, request_date, computer_name, ip_address, access_basis, iys):
	global flag_add_request

	c = conn.cursor()
	c.execute('''
		SELECT id_request FROM request 
		WHERE id_org = ? AND request_number = ? AND request_date = ? 
		AND computer_name = ? AND ip_address = ? AND access_basis = ? AND iys = ?
	''', (id_org, request_number, request_date, computer_name, ip_address, access_basis, iys))

	row = c.fetchone()
	if row:
		id_request = row[0]
		#print(f"Заявка уже есть: {request_number}, id={id_request}")
		flag_add_request = True
		return id_request
	else:
		c.execute('''
			INSERT INTO request (id_org, request_number, request_date, 
							   computer_name, ip_address, access_basis, iys)
			VALUES (?, ?, ?, ?, ?, ?, ?)
		''', (id_org, request_number, request_date, computer_name, ip_address, access_basis, iys))
		
		id_request = c.lastrowid
		#print(f"Добавлена новая заявка: {request_number}, id={id_request}")
		conn.commit()
		return id_request

def add_main_work(conn, id_request, main_work_data):
    """
    Добавляет основную работу только если такой еще нет
    Возвращает id_main_work
    """
    c = conn.cursor()
    
    # Проверяем существование
    c.execute('''
        SELECT id_main_work FROM main_work 
        WHERE id_request = ? 
        AND is_new_user = ? AND is_test_zone = ? AND is_prod_zone = ?
        AND need_client_install = ? AND is_arm_connect = ? 
        AND is_arm_disconnect = ? AND is_arm_change = ?
        AND is_ivs = ? AND is_evspd = ? AND is_internet = ?
        AND note = ?
    ''', (
        id_request,
        int(main_work_data.get("is_new_user", False)),
        int(main_work_data.get("is_test_zone", False)),
        int(main_work_data.get("is_prod_zone", False)),
        int(main_work_data.get("need_client_install", False)),
        int(main_work_data.get("is_arm_connect", False)),
        int(main_work_data.get("is_arm_disconnect", False)),
        int(main_work_data.get("is_arm_change", False)),
        int(main_work_data.get("is_ivs", False)),
        int(main_work_data.get("is_evspd", False)),
        int(main_work_data.get("is_internet", False)),
        main_work_data.get("note", "")
    ))
    
    row = c.fetchone()
    if row:
        id_main_work = row[0]
        #print(f"  Основная работа уже есть, id={id_main_work}")
        return id_main_work
    else:
        c.execute('''
            INSERT INTO main_work (
                id_request, is_new_user, is_test_zone, is_prod_zone,
                need_client_install, is_arm_connect, is_arm_disconnect,
                is_arm_change, is_ivs, is_evspd, is_internet, note
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            id_request,
            int(main_work_data.get("is_new_user", False)),
            int(main_work_data.get("is_test_zone", False)),
            int(main_work_data.get("is_prod_zone", False)),
            int(main_work_data.get("need_client_install", False)),
            int(main_work_data.get("is_arm_connect", False)),
            int(main_work_data.get("is_arm_disconnect", False)),
            int(main_work_data.get("is_arm_change", False)),
            int(main_work_data.get("is_ivs", False)),
            int(main_work_data.get("is_evspd", False)),
            int(main_work_data.get("is_internet", False)),
            main_work_data.get("note", "")
        ))
        id_main_work = c.lastrowid
        #print(f"  Добавлена новая основная работа, id={id_main_work}")
        conn.commit()
        return id_main_work

def add_role(conn, id_main_work, role_data):
    """
    Добавляет роль в ROLE_TABLE
    Возвращает id_role
    """
    c = conn.cursor()
    
    # Проверяем существование
    c.execute('''
        SELECT id_role FROM role_table 
        WHERE id_main_work = ? AND action = ? AND sid_mandant = ?
        AND functional_role = ? AND role_code = ? AND org_role = ?
    ''', (
        id_main_work,
        role_data.get("action", ""),
        role_data.get("sid_mandant", ""),
        role_data.get("functional_role", ""),
        role_data.get("role_code", ""),
        role_data.get("org_role", "")
    ))
    
    row = c.fetchone()
    if row:
        id_role = row[0]
        #print(f"    Роль уже есть: {role_data.get('functional_role')}, id={id_role}")
        return id_role
    else:
        c.execute('''
            INSERT INTO role_table (
                id_main_work, action, sid_mandant,
                functional_role, role_code, org_role
            ) VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            id_main_work,
            role_data.get("action", ""),
            role_data.get("sid_mandant", ""),
            role_data.get("functional_role", ""),
            role_data.get("role_code", ""),
            role_data.get("org_role", "")
        ))
        id_role = c.lastrowid
        #print(f"    Добавлена новая роль: {role_data.get('functional_role')}, id={id_role}")
        conn.commit()
        return id_role
        
def add_boss(conn, id_request, request):
    """
    Добавляет должностное лицо в таблицу bosses
    Возвращает group_id
    """
    c = conn.cursor()
    
    # Сортируем request для последовательного сравнения
    sorted_request = sorted(request, key=lambda x: x.get("role_type", ""))
    
    # Получаем все существующие группы для этой заявки
    c.execute('''
        SELECT group_id, full_name, role_type FROM bosses 
        WHERE id_request = ?
        ORDER BY group_id, role_type
    ''', (id_request,))
    
    existing = c.fetchall()
    
    # Группируем существующие записи по group_id
    from collections import defaultdict
    groups_dict = defaultdict(list)
    for group_id, full_name, role_type in existing:
        groups_dict[group_id].append((full_name, role_type))
    
    # Проверяем, есть ли уже такая группа
    for group_id, records in groups_dict.items():
        if len(records) == len(sorted_request):
            # Сортируем существующие записи
            sorted_records = sorted(records, key=lambda x: x[1])
            match = True
            for i, (full_name, role_type) in enumerate(sorted_records):
                if (full_name != sorted_request[i].get("full_name", "") or 
                    role_type != sorted_request[i].get("role_type", "")):
                    match = False
                    break
            if match:
                #print(f"Блок уже существует, group_id={group_id}")
                return group_id
    
    # Создаем новую группу
    c.execute('SELECT COALESCE(MAX(group_id), 0) + 1 FROM bosses WHERE id_request = ?', (id_request,))
    new_group_id = c.fetchone()[0]
    
    for boss_data in sorted_request:
        c.execute('''
            INSERT INTO bosses (id_request, full_name, role_type, group_id)
            VALUES (?, ?, ?, ?)
        ''', (
            id_request,
            boss_data.get("full_name", ""),
            boss_data.get("role_type", ""),
            new_group_id
        ))
    
    conn.commit()
    #print(f"Добавлен новый блок, group_id={new_group_id}")
    return new_group_id
        
def add_person(conn, last_name, first_name, middle_name, email, position, phone):
    c = conn.cursor()
    
    c.execute('''
        SELECT id_person FROM person 
        WHERE last_name = ? AND first_name = ? AND middle_name = ? 
        AND email = ? AND position = ? AND phone = ?''', 
        (last_name, first_name, middle_name, email, position, phone))

    row = c.fetchone()
    if row:
        return row[0]

    c.execute('''
        INSERT INTO person (last_name, first_name, middle_name, position, email, phone)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (last_name, first_name, middle_name, position, email, phone))

    conn.commit()
    return c.lastrowid


def supervisor(conn, last_name, first_name, middle_name, email):
    c = conn.cursor()
    
    # Ищем руководителя (position NULL, phone NULL)
    c.execute('''
        SELECT id_person FROM person 
        WHERE last_name = ? AND first_name = ? AND middle_name = ? 
        AND email = ? AND position IS NULL AND phone IS NULL''', 
        (last_name, first_name, middle_name, email))

    row = c.fetchone()
    if row:
        return row[0]

    # Создаем нового руководителя
    c.execute('''
        INSERT INTO person (last_name, first_name, middle_name, position, email, phone)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (last_name, first_name, middle_name, None, email, None))  # 👈 position=None, phone=None

    conn.commit()
    return c.lastrowid

def writeFile(data):
	"""
	Записывает данные из JSON в базу данных
	"""

	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)

	global flag_add_organization
	global flag_add_request

	for request in data["requests"]:
		# 1. Организация
		org_data = request["organization"]
		id_org = add_organization(conn, 
			org_data["org_name"],
			org_data["department"],
			org_data["address"]
		)
		
		#print(f"id_org = {id_org}")
		
		# 2. Заявка
		req_data = request["request"]
		id_request = add_request(conn,
			id_org,
			req_data["request_number"],
			req_data["request_date"],
			req_data["computer_name"],
			req_data["ip_address"],
			req_data["access_basis"],
			req_data["iys"]
		)
		#print(f"id_request = {id_request}")
		
		if flag_add_organization and flag_add_request:
			flag_add_organization = False
			flag_add_request = False
			return False
		
		# 3. Основная работа
		mw_data = request["main_work"]
		id_main_work = add_main_work(conn, id_request, mw_data)
		
		#print(f"id_main_work = {id_main_work}")

		# 4. Роли
		for role_data in request["roles"]:
			add_role(conn, id_main_work, role_data)
			
		#print(f"role_data = {role_data}")
		
		# 5. Добавляем заявителя (applicant)
		applicant_data = request["applicant"]
		id_applicant = add_person(conn,
			applicant_data["last_name"],
			applicant_data["first_name"],
			applicant_data["middle_name"],
			applicant_data["email"],
			applicant_data["position"],
			applicant_data["phone"]
		)
		
		#print(f"id_applicant = {id_applicant}")

		# 6. Добавляем руководителя (supervisor)
		supervisor_data = request["supervisor"] 
		id_supervisor = supervisor(conn,
			supervisor_data["last_name"],
			supervisor_data["first_name"],
			supervisor_data["middle_name"],
			supervisor_data["email"],
		)

		#print(f"id_supervisor = {id_supervisor}")

		c = conn.cursor()
		c.execute('''
			SELECT COUNT(*) FROM person_in_request 
			WHERE id_request = ? AND id_person = ?''', 
		(id_request, id_applicant))
		count_apl = c.fetchone()[0]

		c.execute('''
			SELECT COUNT(*) FROM person_in_request 
			WHERE id_request = ? AND id_person = ?''', 
		(id_request, id_supervisor))
		count_ser = c.fetchone()[0]

		if count_apl == 0 or count_ser == 0:
			# 7-8. Получаем pair_id и вставляем
			cursor = conn.execute('SELECT COALESCE(MAX(pair_id), 0) + 1 FROM person_in_request WHERE id_request = ?', (id_request,))
			pair_id = cursor.fetchone()[0]

			conn.execute('''
				INSERT OR IGNORE INTO person_in_request (id_request, id_person, role_type, pair_id)
				VALUES (?, ?, ?, ?), (?, ?, ?, ?)
			''', (id_request, id_applicant, 'applicant', pair_id,
				  id_request, id_supervisor, 'supervisor', pair_id))

		# 9. Добавляем должностных лиц
		add_boss(conn, id_request, request["officials"])

	conn.commit()
	conn.close()
	
	return True
