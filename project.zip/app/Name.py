def name(mas):
    if (mas == ""):
        return True
	
    if len(mas) < 7:  # Минимум "А А. А." - 7 символов
        return False
    
    if (mas[-1] == '.' and              # последняя точка
        mas[-2].isupper() and            # предпоследняя - заглавная буква
        mas[-3] == ' ' and               # пробел
        mas[-4] == '.' and               # точка
        mas[-5].isupper() and            # заглавная буква
        mas[-6] == ' ' and               # пробел
        mas[0].isupper()):               # первая буква заглавная
        return mas
    
    return False
    
    
def data_processing(main_table, role_table):
    result = {
        "requests": [
            {
                "organization": {},
                "request": {},
                "applicant": {},
                "supervisor": {},
                "main_work": {},
                "roles": [],
                "officials": []
            }
        ]
    }
    
    # Определяем, есть ли заголовок в role_table
    if role_table and role_table[0] and str(role_table[0][0]).isdigit():
        has_header = False   # первая строка - это данные (нет заголовка)
    else:
        has_header = True    # есть строка с заголовком

    # Обработка ролей
    mas_roles = []
    start_index = 1 if has_header else 0  # если есть заголовок - пропускаем его

    for i in range(start_index, len(role_table)):
        role = {
        "action": role_table[i][1],
        "sid_mandant": role_table[i][2],
        "functional_role": role_table[i][3],
        "role_code": role_table[i][4],
        "org_role": role_table[i][5]
        }
        mas_roles.append(role)

    result["requests"][0]["roles"] = mas_roles
	    
	# Обработка основной таблицы
    res = {}  # для officials
    for row in main_table:
        # organization
        if row[0] == "Организация":
            result["requests"][0]["organization"]["org_name"] = row[1]
        elif row[0] == "Подразделение":
            result["requests"][0]["organization"]["department"] = row[1]
        elif row[0] == "Адрес":
            result["requests"][0]["organization"]["address"] = row[1]
        
        # request
        elif row[0] == "№ заявки":
            result["requests"][0]["request"]["request_number"] = row[1]
        elif row[0] == "Дата заполнения":
            result["requests"][0]["request"]["request_date"] = row[1]
        elif row[0] == "Имя компьютера":
            result["requests"][0]["request"]["computer_name"] = row[1]
        elif row[0] == "IP адрес":
            result["requests"][0]["request"]["ip_address"] = row[1]
        elif row[0] == "Основание доступа":
            result["requests"][0]["request"]["access_basis"] = row[1]
        elif row[0] == "ИP_ИУС":
            result["requests"][0]["request"]["iys"] = row[1]
        
        # main_work
        elif row[0] == "Новый пользователь":
            result["requests"][0]["main_work"]["is_new_user"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Зона тестирования":
            result["requests"][0]["main_work"]["is_test_zone"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Зона эксплуатации":
            result["requests"][0]["main_work"]["is_prod_zone"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Установка клиентской части":
            result["requests"][0]["main_work"]["need_client_install"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Подключение АРМ":
            result["requests"][0]["main_work"]["is_arm_connect"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Отключение АРМ":
            result["requests"][0]["main_work"]["is_arm_disconnect"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Изменение АРМ":
            result["requests"][0]["main_work"]["is_arm_change"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "ИВС":
            result["requests"][0]["main_work"]["is_ivs"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "ЕВСПД":
            result["requests"][0]["main_work"]["is_evspd"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Интернет":
            result["requests"][0]["main_work"]["is_internet"] = "1" if row[1].lower() == "да" else "0"
        elif row[0] == "Примечание":
            result["requests"][0]["main_work"]["note"] = row[1]
        
        # applicant
        elif row[0] == "Фамилия":
            result["requests"][0]["applicant"]["last_name"] = row[1]
        elif row[0] == "Имя":
            result["requests"][0]["applicant"]["first_name"] = row[1]
        elif row[0] == "Отчество":
            result["requests"][0]["applicant"]["middle_name"] = row[1]
        elif row[0] == "Должность":
            result["requests"][0]["applicant"]["position"] = row[1]
        elif row[0] == "E-mail":
            result["requests"][0]["applicant"]["email"] = row[1]
        elif row[0] == "Телефон":
            result["requests"][0]["applicant"]["phone"] = row[1]
        
        # supervisor
        elif row[0] == "ФИО руководителя":
            bossName = name(row[1])
            if bossName == True:
                result["requests"][0]["supervisor"]["last_name"] = ""
                result["requests"][0]["supervisor"]["first_name"] = ""
                result["requests"][0]["supervisor"]["middle_name"] = ""
            elif bossName == False:
                return {"status": "abort", "message": f"Введите корректно ФИО руководителя или оставьте пустым. Пример: Иванов И. И."}
            else:
                lfm_name = bossName.split(' ')
                if len(lfm_name) >= 3:
                    result["requests"][0]["supervisor"]["last_name"] = lfm_name[0]
                    result["requests"][0]["supervisor"]["first_name"] = lfm_name[1]
                    result["requests"][0]["supervisor"]["middle_name"] = lfm_name[2]
        elif row[0] == "E-mail руководителя":
            result["requests"][0]["supervisor"]["email"] = row[1]
        
        # officials
        elif row[0] == "email Администратор АРМ":
            res = {"full_name": row[1], "role_type": "admin_arm"}
            result["requests"][0]["officials"].append(res)
        elif row[0] == "email АИБ":
            res = {"full_name": row[1], "role_type": "aib"}
            result["requests"][0]["officials"].append(res)
        elif row[0] == "ФИО Контакт-центр":
            bossName = name(row[1])
            if bossName == False:
                return {"status": "abort", "message": f"Введите корректно ФИО Контакт-центр или оставьте пустым. Пример: Иванов И. И."}
            res = {"full_name": row[1], "role_type": "contact_center"}
            result["requests"][0]["officials"].append(res)
        elif row[0] == "ФИО Центр кибербезопасности":
            bossName = name(row[1])
            if bossName == False:
                return {"status": "abort", "message": f"Введите корректно ФИО Центр кибербезопасности или оставьте пустым. Пример: Иванов И. И."}
            res = {"full_name": row[1], "role_type": "security"}
            result["requests"][0]["officials"].append(res)
        elif row[0] == "ФИО Владелец":
            bossName = name(row[1])
            if bossName == False:
                return {"status": "abort", "message": f"Введите корректно ФИО Владелец или оставьте пустым. Пример: Иванов И. И."}
            res = {"full_name": row[1], "role_type": "owner"}
            result["requests"][0]["officials"].append(res)
               
    return result
    
def convertData(data):
	data_conv = [
		data["requests"][0]["request"]["iys"],
		data["requests"][0]["request"]["request_number"],
		data["requests"][0]["request"]["request_date"],
		
		data["requests"][0]["organization"]["org_name"],
		data["requests"][0]["organization"]["department"],
		data["requests"][0]["organization"]["address"],
		
		data["requests"][0]["applicant"]["last_name"],
		data["requests"][0]["applicant"]["first_name"],
		data["requests"][0]["applicant"]["middle_name"],
		data["requests"][0]["applicant"]["position"],
		data["requests"][0]["applicant"]["email"],
		data["requests"][0]["applicant"]["phone"],		

		data["requests"][0]["request"]["computer_name"],
		data["requests"][0]["request"]["ip_address"],			
		data["requests"][0]["request"]["access_basis"],	
		
		data["requests"][0]["supervisor"]["email"],
		data["requests"][0]["supervisor"]["last_name"] + " " + data["requests"][0]["supervisor"]["first_name"] + " " + data["requests"][0]["supervisor"]["middle_name"],			
		
		data["requests"][0]["main_work"]["is_new_user"],
		data["requests"][0]["main_work"]["is_test_zone"],
		data["requests"][0]["main_work"]["is_prod_zone"],
		data["requests"][0]["main_work"]["note"],
		data["requests"][0]["main_work"]["need_client_install"],
		data["requests"][0]["main_work"]["is_arm_connect"],
		data["requests"][0]["main_work"]["is_arm_disconnect"],
		data["requests"][0]["main_work"]["is_arm_change"],
		data["requests"][0]["main_work"]["is_ivs"],
		data["requests"][0]["main_work"]["is_evspd"],
		data["requests"][0]["main_work"]["is_internet"],
		
		data["requests"][0]["officials"][0]["full_name"],
		data["requests"][0]["officials"][1]["full_name"],
		data["requests"][0]["officials"][2]["full_name"],
		data["requests"][0]["officials"][3]["full_name"],
		data["requests"][0]["officials"][4]["full_name"]
	]
	
	data_role_conv = [["", "Добавить/Удалить", "SID/Мандант", "Функциональная роль/Бизнес-роль", "Код роли", "Организационная роль/Объект полномочий"]]
	for i in range(len(data["requests"][0]["roles"])):
		mas = [
			i+1,
			data["requests"][0]["roles"][i]["action"],
			data["requests"][0]["roles"][i]["sid_mandant"],
			data["requests"][0]["roles"][i]["functional_role"],
			data["requests"][0]["roles"][i]["role_code"],
			data["requests"][0]["roles"][i]["org_role"]	
		]
		data_role_conv.append(mas)
	
	return [data_conv, data_role_conv]
