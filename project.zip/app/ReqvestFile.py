import sqlite3
import os

def reqvestFile():
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project/
	DATA_DIR = os.path.join(BASE_DIR, 'data')      # project/frontend/
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	c = conn.cursor()
	
	fields = [
			"ИP_ИУС",
			"№ заявки",
			"Дата заполнения",
			
			"ДАННЫЕ О ПОЛЬЗОВАТЕЛЕ",
			"Организация",
			"Подразделение", 
			"Адрес",
			"Фамилия",
			"Имя",
			"Отчество",
			"Должность",
			"E-mail",
			"Телефон",
			"Имя компьютера",
			"IP адрес",
			"Основание доступа",
			"E-mail руководителя",
			"ФИО руководителя",
			
			"СИСТЕМНЫЕ РЕКВИЗИТЫ",
			"Новый пользователь",
			"Зона тестирования",
			"Зона эксплуатации",
			"Подробная информация",
			"Примечание",
			
			"ПОДКЛЮЧЕНИЕ РАБОЧЕГО МЕСТА",
			"Установка клиентской части",
			"Подключение АРМ",
			"Отключение АРМ",
			"Изменение АРМ",
			"ИВС",
			"ЕВСПД",
			"Интернет",
			"email Администратор АРМ",
			"email АИБ",
			
			"СОГЛАСОВАНО",
			"ФИО Контакт-центр",
			"ФИО Центр кибербезопасности",
			"ФИО Владелец"
		]

	c.execute('''SELECT id_org, org_name, department, address FROM organization''')
	rows = c.fetchall()
	data_organization = [{"id_org": row[0], "org_name": row[1], "department": row[2], "address": row[3]} for row in rows]
	
	#data_organization_data = data_organization.copy()
		
	data_request = []  # ← добавил
	for i in range(len(data_organization)):
		c.execute('''SELECT id_request, request_number, request_date, 
		computer_name, ip_address, access_basis, iys FROM request
		WHERE id_org = ?''', (data_organization[i]["id_org"],))  # ← исправлено
		rows = c.fetchall()
	
		data_request.extend([{"iys": row[6], "id_request": row[0], "request_number": row[1],  # ← row[1] а не row[2]
		"request_date": row[2], "computer_name": row[3],
		"ip_address": row[4], "access_basis": row[5], "org_name": data_organization[i]["org_name"],
		"department": data_organization[i]["department"],  # ← исправлено
		"address": data_organization[i]["address"]} for row in rows])  # ← исправлено	
	
	data_main_work = []
	for i in range(len(data_request)):
		c.execute('''SELECT id_main_work, is_new_user, is_test_zone, is_prod_zone,
		need_client_install, is_arm_connect, is_arm_disconnect, is_arm_change,
		is_ivs, is_evspd, is_internet, note FROM main_work 
		WHERE id_request = ?''', (data_request[i]["id_request"],))
		rows = c.fetchall()
		
		for row in rows:  # ← проходим по каждой строке main_work
			c.execute('''SELECT action, sid_mandant, functional_role,
			role_code, org_role FROM role_table 
			WHERE id_main_work = ?''', (row[0],))  # ← передаем id_main_work из текущей строки
			
			role_rows = c.fetchall()
			role_table_list = [dict(zip(['action', 'sid_mandant', 'functional_role', 'role_code', 'org_role'], r)) for r in role_rows]
			
			data_main_work.append({
				"role": role_table_list,
				"is_new_user": row[1],
				"is_test_zone": row[2],
				"is_prod_zone": row[3],
				"need_client_install": row[4],
				"is_arm_connect": row[5],
				"is_arm_disconnect": row[6],
				"is_arm_change": row[7],
				"is_ivs": row[8],
				"is_evspd": row[9],
				"is_internet": row[10],
				"note": row[11],
				"iys": data_request[i]["iys"],
				"id_request": data_request[i]["id_request"],
				"request_number": data_request[i]["request_number"],
				"request_date": data_request[i]["request_date"],
				"computer_name": data_request[i]["computer_name"],
				"ip_address": data_request[i]["ip_address"],
				"access_basis": data_request[i]["access_basis"],
				"department": data_request[i]["department"],
				"address": data_request[i]["address"],
				"org_name": data_request[i]["org_name"]
			})
	
	data_boss = []
	for i in range(len(data_main_work)): 
		c.execute('''SELECT full_name, role_type, group_id FROM bosses 
		WHERE id_request = ?''', (data_main_work[i]["id_request"],))
		rows = c.fetchall()
		
		# Инициализируем значения по умолчанию
		admin_arm = None
		aib = None
		contact_center = None
		security = None
		owner = None
		
		# Сортируем по последнему значению
		rows.sort(key=lambda x: x[2])

		# Группируем
		result = []
		current_group = []
		current_key = None

		for item in rows:
			if item[2] != current_key:
				if current_group:
					result.append(current_group)
				current_group = [item]
				current_key = item[2]
			else:
				current_group.append(item)

		if current_group:
			result.append(current_group)
		
		#print(result)

		for rows in result:
			for row in rows:
				#print(row)
				if row[1] == "admin_arm":
					admin_arm = row[0]
				elif row[1] == "aib":
					aib = row[0]
				elif row[1] == "contact_center":
					contact_center = row[0]
				elif row[1] == "security":
					security = row[0]
				elif row[1] == "owner":
					owner = row[0]
			#print()
						
			# Добавляем ОДНУ запись после обработки всех строк bosses
			data_boss.append({
				"admin_arm": admin_arm,
				"aib": aib,
				"contact_center": contact_center,
				"security": security,
				"owner": owner,
				"role": data_main_work[i]["role"],
				"is_new_user": data_main_work[i]["is_new_user"],
				"is_test_zone": data_main_work[i]["is_test_zone"],
				"is_prod_zone": data_main_work[i]["is_prod_zone"],
				"need_client_install": data_main_work[i]["need_client_install"],
				"is_arm_connect": data_main_work[i]["is_arm_connect"],
				"is_arm_disconnect": data_main_work[i]["is_arm_disconnect"],
				"is_arm_change": data_main_work[i]["is_arm_change"],
				"is_ivs": data_main_work[i]["is_ivs"],
				"is_evspd": data_main_work[i]["is_evspd"],
				"is_internet": data_main_work[i]["is_internet"],
				"note": data_main_work[i]["note"],
				"iys": data_main_work[i]["iys"],
				"id_request": data_main_work[i]["id_request"],
				"request_number": data_main_work[i]["request_number"],
				"request_date": data_main_work[i]["request_date"],
				"computer_name": data_main_work[i]["computer_name"],
				"ip_address": data_main_work[i]["ip_address"],
				"access_basis": data_main_work[i]["access_basis"],
				"department": data_main_work[i]["department"],
				"address": data_main_work[i]["address"],
				"org_name": data_main_work[i]["org_name"],
				"role": data_main_work[i]["role"]
			})

	data_person_in_request = []
	for i in range(len(data_boss)): 
		c.execute('''SELECT id_person, role_type, pair_id FROM person_in_request 
		WHERE id_request = ?''', (data_boss[i]["id_request"],))
		rows = c.fetchall()
			
		data_applicant = {
			"last_name": None,
			"first_name": None,
			"middle_name": None,
			"email": None,
			"position": None,
			"phone": None
		}
		data_supervisor = {
			"last_name": None,
			"first_name": None,
			"middle_name": None,
			"email": None,
			"position": None,
			"phone": None
		}
		
		# Сортируем по последнему значению (pair_id)
		rows.sort(key=lambda x: x[2])

		# Группируем
		grouped_result = []  # ← переименовал, чтобы не путать
		current_group = []
		current_key = None

		for item in rows:
			if item[2] != current_key:
				if current_group:
					grouped_result.append(current_group)
				current_group = [item]
				current_key = item[2]
			else:
				current_group.append(item)

		if current_group:
			grouped_result.append(current_group)
		
		#print()
			
		# Теперь обрабатываем каждую группу
		for group in grouped_result:  # ← используем grouped_result
			for row in group:  # ← переименовал, чтобы не путать с rows
				c.execute('''
					SELECT last_name, first_name, middle_name, email, position, phone
					FROM person 
					WHERE id_person = ?''', (row[0],))
				ro = c.fetchone()
				
				if ro:  # проверка, что данные есть
					if row[1] == "applicant":
						data_applicant = {
							"last_name": ro[0] if ro[0] else "",
							"first_name": ro[1] if ro[1] else "",
							"middle_name": ro[2] if ro[2] else "",
							"email": ro[3] if ro[3] else "",
							"position": ro[4] if ro[4] else "",
							"phone": ro[5] if ro[5] else ""
						}
					elif row[1] == "supervisor":
						data_supervisor = {
							"last_name": ro[0] if ro[0] else "",
							"first_name": ro[1] if ro[1] else "",
							"middle_name": ro[2] if ro[2] else "",
							"email": ro[3] if ro[3] else "",
							"position": None,
							"phone": None
						}
			
			# Добавляем данные после обработки группы
			data_person_in_request.append({
				"iys": data_boss[i]["iys"],
				"request_number": data_boss[i]["request_number"],
				"request_date": data_boss[i]["request_date"],
				
				"org_name": data_boss[i]["org_name"],
				"department": data_boss[i]["department"],
				"address": data_boss[i]["address"],        
						
				"last_name_applicant": data_applicant["last_name"],
				"first_name_applicant": data_applicant["first_name"],
				"middle_name_applicant": data_applicant["middle_name"],
				"applicant_position": data_applicant["position"],
				"applicant_email": data_applicant["email"], 
				"applicant_phone": data_applicant["phone"],
				
				"computer_name": data_boss[i]["computer_name"],
				"ip_address": data_boss[i]["ip_address"],
				"access_basis": data_boss[i]["access_basis"],
				 
				"supervisor_email": data_supervisor["email"],
				"name_supervisor": (data_supervisor["last_name"] + ' ' +
									data_supervisor["first_name"] + ' ' +
									data_supervisor["middle_name"]).strip(),
						
				"is_new_user": data_boss[i]["is_new_user"],
				"is_test_zone": data_boss[i]["is_test_zone"],
				"is_prod_zone": data_boss[i]["is_prod_zone"],
				"role": data_boss[i]["role"],
				"note": data_boss[i]["note"],
				"need_client_install": data_boss[i]["need_client_install"],
				"is_arm_connect": data_boss[i]["is_arm_connect"],
				"is_arm_disconnect": data_boss[i]["is_arm_disconnect"],
				"is_arm_change": data_boss[i]["is_arm_change"],
				"is_ivs": data_boss[i]["is_ivs"],
				"is_evspd": data_boss[i]["is_evspd"],
				"is_internet": data_boss[i]["is_internet"],
				
				"admin_arm": data_boss[i]["admin_arm"],
				"aib": data_boss[i]["aib"],
				"contact_center": data_boss[i]["contact_center"],
				"security": data_boss[i]["security"],
				"owner": data_boss[i]["owner"]
			})

	data_data = []
	for i in data_person_in_request:
		data_cort = {"data": [], "role": None}
		for key, value in i.items():
			if key != "role":
				data_cort["data"].append(value)
			else:
				d = []
				for j in value:
					mas = []
					for k, v in j.items():
						mas.append(v)
					d.append(mas)
				data_cort["role"] = d
		data_data.append(data_cort)
	
	data_v = []
	data_t = []
	for idx, i in enumerate(data_data, start=1):
		data_v.append(tuple(i["data"]))
		data_t.append([[j] + item for j, item in enumerate(i["role"], start=1)])
	

	transposed_data = list(zip(*data_v))
	
	fields_role_table = ["№ п/п",
						 "Добавить/Удалить", 
	                     "SID/Мандат", 
	                     "Функциональная роль/Бизнес-роль", 
	                     "Код роли", 
	                     "Организационная роль/Объект полномочий"]
	                     
	conn.close()
	
	return fields, transposed_data, fields_role_table, data_t
