from WriteFile import writeFile
from ReqvestFile import reqvestFile
from fastapi import FastAPI, Request, Depends, HTTPException, Header, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
import uvicorn
import webbrowser
from threading import Timer
import os
from bs4 import BeautifulSoup
from WriteExcel import writeExcel, dataExcel, order_number_req
from Name import name, data_processing, convertData
from pdfFile import pdfFile
from datetime import datetime, timedelta
from RemoveBD import removeBD
import jwt
import secrets
import sqlite3
import bcrypt
from Passwords import password_data, delete_superdata_help, add_superdata_help, change_superadmin_help

# Определяем путь к папке frontend
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')
app = FastAPI()

# Подключаем статические файлы
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

# Функция проверки администратора
def verify_user(indf: int, login: str, password: str) -> bool:
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project/
	DATA_DIR = os.path.join(BASE_DIR, 'data')      # project/frontend/
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	cursor = conn.cursor()
	cursor.execute('SELECT password_hash FROM passwords WHERE login = ? AND indf = ?', (login, indf))
	result = cursor.fetchone()
	conn.close()

	if not result:
		return False

	stored_hash = result[0]
	return bcrypt.checkpw(password.encode(), stored_hash)

# Функция проверки системного администратора
def verify_admin(login: str, password: str) -> bool:
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project/
	DATA_DIR = os.path.join(BASE_DIR, 'data')      # project/frontend/
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	cursor = conn.cursor()
	
	cursor.execute('SELECT password_hash FROM passwords_admin_system WHERE login = ?', (login,))
	result = cursor.fetchone()
	conn.close()

	if not result:
		return False

	stored_hash = result[0]
	return bcrypt.checkpw(password.encode(), stored_hash)

# Генерируем безопасный ключ
SECRET_KEY = secrets.token_hex(32)

# Главная страница (админка с формой входа)
@app.get("/", response_class=HTMLResponse)
async def read_root():
    file_path = os.path.join(FRONTEND_DIR, "management.html")
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

# Главная страница (админка с формой входа)
@app.post("/admin", response_class=HTMLResponse)
async def read_root():
    file_path = os.path.join(FRONTEND_DIR, "admin.html")
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

# Эндпоинт для входа
@app.post("/api/login")
async def login(credentials: HTTPBasicCredentials = Depends(HTTPBasic())):
	admin = credentials.username
	password = credentials.password

	if not verify_user(1, admin, password):
		raise HTTPException(status_code=401, detail="Неверный логин или пароль")

	token = jwt.encode(
		{
			"sub": admin,
			"exp": datetime.utcnow() + timedelta(hours=1)
		},
		SECRET_KEY,
		algorithm="HS256"
	)

	return {"status": "success", "token": token}

# Защищенный эндпоинт с данными
@app.get("/api/data")
async def get_data(authorization: str = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    
    token = authorization.replace("Bearer ", "")
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        username = payload.get("sub")
        print(f"Пользователь {username} запросил данные")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Токен просрочен")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Неверный токен")
    
    reqvest_file = reqvestFile()
    fields = reqvest_file[0]
    data = reqvest_file[1]
    fields_role_table = reqvest_file[2]
    data_role_table = reqvest_file[3]

    return {
        "fields": fields,
        "data": data,
        "fields_role_table": fields_role_table,
        "data_role_table": data_role_table,
    }
    
#Запрос на SQL файл
#--------------------------------------------------#

#Суперадмин
#--------------------------------------------------#
# Запуск
@app.post("/superadmin", response_class=HTMLResponse)
async def read_root():
    file_path = os.path.join(FRONTEND_DIR, "superadmin.html")
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()
        
# Эндпоинт для входа (без HTTPBasic)
@app.post("/api/login_system_admin")
async def login(request: Request):
	data = await request.json()
	admin = data.get('login')
	password = data.get('password')

	if not verify_admin(admin, password):
		raise HTTPException(status_code=401, detail="Неверный логин или пароль")
		
	return {"status": "success"}
        
# Запонение данными
@app.post("/api/superdata")
async def get_data_superdata(authorization: str = Header(None)):   
    data = password_data()
    
    return {"status": "ok", "data": data}
    
# Удаление данных
@app.post("/api/delete_superdata")
async def delete_superdata(request: Request):
    # Получаем JSON из тела запроса
    data = await request.json()
    
    # Забираем id
    id_superdata = data.get('id')
    
    # Вызываем функцию удаления
    delete_superdata_help(id_superdata)
    
    return {"status": "ok"}  # ← полностью латиницей "ok"
    
# Добавление данных
@app.post("/api/add_superdata")
async def add_superdata(request: Request):
	# Получаем JSON из тела запроса
	data = await request.json()
				
	# Забираем id
	login = data.get('login')	
	password = data.get('password')
	indf = data.get('indf')
	
	add = add_superdata_help(login, password, indf)
	if add["status"] == 'error':
		return {"status": "error", "error": add["error"]}  # ← ключ "error"
	else:
		return {"status": "ok"}

# Изменение данных для суперадмина
@app.post("/api/change_superadmin")
async def change_superadmin(request: Request):
    # Получаем JSON из тела запроса
    data = await request.json()
    			
    # Забираем id
    login = data.get('login')	
    password = data.get('password')
    
    change_superadmin_help(login, password)
    
    return {"status": "ok"}   
           
#Суперадмин
#--------------------------------------------------#

#Запись SQL файл
#--------------------------------------------------#
@app.post("/user", response_class=HTMLResponse)
async def read_root():
    file_path = os.path.join(FRONTEND_DIR, "user.html")
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()
        
# На сервере (пример для Flask/FastAPI)
@app.post("/api/login_user")
async def login(request: Request):
	data = await request.json()
	admin = data.get('login')
	password = data.get('password')

	if not verify_user(2, admin, password):
		raise HTTPException(status_code=401, detail="Неверный логин или пароль")
		
	return {"status": "success"}
        
@app.get("/api/data_user")
async def get_data(authorization: str = Header(None)):
    reqvest_file = reqvestFile()
    fields = reqvest_file[0]
    data = reqvest_file[1]
    fields_role_table = reqvest_file[2]
    data_role_table = reqvest_file[3]

    return {
        "fields": fields,
        "data": data,
        "fields_role_table": fields_role_table,
        "data_role_table": data_role_table,
    }

@app.post("/upload_read_file")
async def upload_file(file: UploadFile = File(...)):
	# 1. Читаем файл из запроса
	contents = await file.read()

	# 2. Создаём папку "../data/tempfiles" (рядом с БД)
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	temp_dir = os.path.join(BASE_DIR, 'data', 'tempfiles')
	os.makedirs(temp_dir, exist_ok=True)

	# 3. Генерируем уникальное имя с датой
	timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
	unique_filename = f"{timestamp}_{file.filename}"

	# 4. Формируем полный путь к файлу
	file_path = os.path.join(temp_dir, unique_filename)

	# 5. Сохраняем файл на диск
	with open(file_path, "wb") as f:
		f.write(contents)

	# 6. Передаём ПУТЬ к файлу в функцию обработки
	data = pdfFile(file_path)

	# 7. Создаем новое имя (ФИО + дата)
	applicant = data["requests"][0]["applicant"]
	request_number = data["requests"][0]["request"]["request_number"]	
	timestamp_for_name = datetime.now().strftime("%Y-%m-%d")  # только дата, без времени
	new_name = f"№{request_number}__ФИО_{applicant['last_name']}_{applicant['first_name']}_{applicant['middle_name']}__Дата_{timestamp_for_name}.pdf"
	new_name = new_name.replace('/', '_').replace(' ', '_')  # чистим от проблемных символов
	new_file_path = os.path.join(temp_dir, new_name)

	# 8. Переименовываем
	os.rename(file_path, new_file_path)

	data_conv = convertData(data)
	#print(data_conv)

	# 9. Возвращаем ответ
	return {"status": "ok", "data": data_conv}
 
#Запись SQL файл
#--------------------------------------------------#

#Удаление SQL данных
#--------------------------------------------------#
@app.post('/delete-request')
async def delete_request(request: Request):
	data = await request.json()

	# Берём токен из тела запроса
	token = data.get('token')  # ← теперь data существует

	if not token:
		raise HTTPException(status_code=401, detail="Токен не передан")

	# Проверяем токен
	try:
		payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
		username = payload.get("sub")
		print(f"Пользователь {username} экспортирует данные")
	except jwt.ExpiredSignatureError:
		raise HTTPException(status_code=401, detail="Токен просрочен")
	except jwt.InvalidTokenError:
		raise HTTPException(status_code=401, detail="Неверный токен")
		
	main_table = data.get('requestData')  # массив данных
	role_table = data.get('requestDataRole')  # массив данных
	 
	result = data_processing(main_table, role_table)
	removeBD(result)

	return {"status": "success", "message": "Заявка удалена"}
	
@app.post("/api/remove_all_data")
async def remove_all_data(request: Request):
	data = await request.json()

	# Берём токен из тела запроса
	token = data.get('token')  # ← теперь data существует

	if not token:
		raise HTTPException(status_code=401, detail="Токен не передан")

	# Проверяем токен
	try:
		payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
		username = payload.get("sub")
		print(f"Пользователь {username} экспортирует данные")
	except jwt.ExpiredSignatureError:
		raise HTTPException(status_code=401, detail="Токен просрочен")
	except jwt.InvalidTokenError:
		raise HTTPException(status_code=401, detail="Неверный токен")
		
	# Удаление данных
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	c = conn.cursor()

	c.execute('DELETE FROM bosses')
	c.execute('DELETE FROM main_work')
	c.execute('DELETE FROM organization')
	c.execute('DELETE FROM person')
	c.execute('DELETE FROM person_in_request')
	c.execute('DELETE FROM request')
	c.execute('DELETE FROM role_table')
	c.execute('DELETE FROM sqlite_sequence')

	conn.commit()
	conn.close()

	return {"status": "success", "message": "Все данные удалены"}
		
#Удаление SQL данных
#--------------------------------------------------#

#Изменение  SQL данных
#--------------------------------------------------#
@app.post('/export-BD-change')
async def export_excel(request: Request):
	data = await request.json()

	# Берём токен из тела запроса
	token = data.get('token')  # ← теперь data существует

	if not token:
		raise HTTPException(status_code=401, detail="Токен не передан")

	# Проверяем токен
	try:
		payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
		username = payload.get("sub")
		print(f"Пользователь {username} экспортирует данные")
	except jwt.ExpiredSignatureError:
		raise HTTPException(status_code=401, detail="Токен просрочен")
	except jwt.InvalidTokenError:
		raise HTTPException(status_code=401, detail="Неверный токен")

	mainTableOld = data.get('mainTableOld')   # старые данные основной таблицы
	roleTableOld = data.get('roleTableOld')   # старые данные таблицы ролей
	mainTableNew = data.get('mainTableNew')   # новые данные основной таблицы
	roleTableNew = data.get('roleTableNew')   # новые данные таблицы ролей

	resultOld = data_processing(mainTableOld, roleTableOld)
	resultNew = data_processing(mainTableNew, roleTableNew)
	if isinstance(resultNew, dict) and "status" in resultNew:
		return {"status": "error", "message": resultNew["message"]}

	removeBD(resultOld)
	if not(writeFile(resultNew)):
		writeFile(resultOld)
		return {"status": "error_change", "message": f"Заявка не изменена — дубликат уже есть в БД"}

	return {"status": "success", "message": f"Изменено"}

#Изменение в BD
#--------------------------------------------------#

#Добавление в BD
@app.post('/export-BD')
async def export_excel(request: Request):  # ← убираем authorization из параметров
	data = await request.json()

	# Берём токен из тела запроса
	token = data.get('token')  # ← теперь data существует

	if not token:
		raise HTTPException(status_code=401, detail="Токен не передан")

	# Проверяем токен
	try:
		payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
		username = payload.get("sub")
		print(f"Пользователь {username} экспортирует данные")
	except jwt.ExpiredSignatureError:
		raise HTTPException(status_code=401, detail="Токен просрочен")
	except jwt.InvalidTokenError:
		raise HTTPException(status_code=401, detail="Неверный токен")

	main_table = data.get('mainTable')
	role_table = data.get('roleTable')
	
	if not main_table or not role_table:
		raise HTTPException(status_code=400, detail="Не переданы mainTable или roleTable")

	result = data_processing(main_table, role_table)
	if isinstance(result, dict) and "status" in result:
		return {"status": "error", "message": result["message"]}

	print(f"result = {result}")

	if not writeFile(result):
		return {
			"status": "error_request", 
			"message": "Такая заявка уже есть..."
		}

	return {"status": "success", "message": "ок"}

#Добавление SQL данных
#--------------------------------------------------#

#Добавление в BD-user
#--------------------------------------------------#
@app.post('/export-user')
async def export_excel(request: Request):
	data = await request.json()
	
	main_table = data.get('mainTable')  # массив данных
	role_table = data.get('roleTable')  # массив данных
	
	print(f"main_table = {main_table}")

	result = data_processing(main_table, role_table)
	if isinstance(result, dict) and "status" in result:
		return {"status": "error", "message": result["message"]}
	
	if not (writeFile(result)):
		return {"status": "error_request", "message": f"Такая заявка от организации в системе уже есть. Если вы считаете сообщение ошибкой, то обратитесь к системному администратору или измените что-то из этих параметров: название организации, подразделение, адрес организации/подразделения, номер заявки, дата заявки, имя компьютера, IP-адрес, основание для доступа "}
	
	# Здесь работаем с массивами, а не парсим HTML
	return {"status": "success", "message": f"ок"}

#Добавление SQL данных
#--------------------------------------------------#

#Экспорт в Excel
#--------------------------------------------------#
@app.post('/export-excel')
async def export_excel(request: Request):
	data = await request.json()

	# Берём токен из тела запроса
	token = data.get('token')  # ← теперь data существует

	if not token:
		raise HTTPException(status_code=401, detail="Токен не передан")

	# Проверяем токен
	try:
		payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
		username = payload.get("sub")
		print(f"Пользователь {username} экспортирует данные")
	except jwt.ExpiredSignatureError:
		raise HTTPException(status_code=401, detail="Токен просрочен")
	except jwt.InvalidTokenError:
		raise HTTPException(status_code=401, detail="Неверный токен")

	html = data.get('html')
	soup = BeautifulSoup(html, 'html.parser')
	order_number = data.get('orderNumber')  # Получаем значение из запроса
	
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project/
	DATA_DIR = os.path.join(BASE_DIR, 'data')      # project/data/
	file_path = DATA_DIR + "/Отчет.xlsx"
	
	if order_number == '':
		order_number = order_number_req(file_path)
			
	applications = dataExcel(soup, order_number)
	if applications == 'error':
		return {"status": "error", "message": "Нельзя добавить пустоту!"}
	
	flag = writeExcel(file_path, applications)

	if flag:
		return {"status": "success", "message": f"Количество сохраненных записей в Excel: {len(applications)}"}
	else:
		return {"status": "error", "message": "Ошибка при записи в файл"}
    
#Экспорт в Excel
#--------------------------------------------------#

if __name__ == "__main__":
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project/
	DATA_DIR = os.path.join(BASE_DIR, 'data')

	# Очистка временных файлов
	temp_dir = os.path.join(DATA_DIR, 'tempfiles')

	if os.path.exists(temp_dir):  # Проверяем существование папки
		for filename in os.listdir(temp_dir):
			file_path = os.path.join(temp_dir, filename)
			if os.path.isfile(file_path):
				try:
					os.remove(file_path)
					print(f"Удален временный файл: {filename}")
				except Exception as e:
					print(f"Не удалось удалить {filename}: {e}")
	else:
		print(f"Папка {temp_dir} не существует, создаем...")
		os.makedirs(temp_dir, exist_ok=True)

	# SSL сертификаты
	SSL_DIR = os.path.join(BASE_DIR, 'gitignore')

	uvicorn.run(
		app, 
		host="0.0.0.0", 
		port=8000,
		ssl_keyfile=os.path.join(SSL_DIR, "key.pem"),
		ssl_certfile=os.path.join(SSL_DIR, "cert.pem")
	)
