import os
import openpyxl
from openpyxl import Workbook

def dataExcel(soup, order_number):
	table_data = []

	for row in soup.find_all('tr'):
		row_data = []
		for cell in row.find_all(['td', 'th']):
			row_data.append(cell.get_text(strip=True))
		if row_data:
			table_data.append(row_data)

	if len(table_data) < 3:
		return 'error'
	
	# Создаем словарь для хранения всех данных
	result = {}

	# Ищем нужные поля
	for row in table_data:
		if row[0] == "Фамилия":
			result["Фамилия"] = row[1:]
		elif row[0] == "Имя":
			result["Имя"] = row[1:]
		elif row[0] == "Отчество":
			result["Отчество"] = row[1:]
		elif row[0] == "Подразделение":
			result["Подразделение"] = row[1:]
		elif row[0] == "Должность":
			result["Должность"] = row[1:]
		elif row[0] == "ИP_ИУС":
			result["ИP_ИУС"] = row[1:]
		elif row[0] == "Дата заполнения":
			result["Дата заполнения"] = row[1:]
		elif row[0] == "Имя компьютера":
			result["Имя компьютера"] = row[1:]
	
	# Транспонируем данные (из столбцов в строки)
	applications = []
	for i in range(len(result["Фамилия"])):
		app = {
			"№ п.п": str(i + int(order_number)),
			"сканы": str(i + int(order_number)),
			"ФИО": result["Фамилия"][i] + ' ' + result["Имя"][i] + ' ' + result["Отчество"][i],
			"Филиал": "",
			"Подразделение": result["Подразделение"][i],
			"Должность": result["Должность"][i],
			"Вид ресурса": "Общественный",
			"Ресурс/роль": result["ИP_ИУС"][i],
			"Тип доступа": "",
			"Дата предоставления": result["Дата заполнения"][i],
			"Дата прекращения":"",
			"Причина прекращения":"",
			"Имя компьютера": result["Имя компьютера"][i]
		}
		applications.append(app)
	
	return applications

def writeExcel(file_path, applications):
    try:       
        if not os.path.exists(file_path):
            wb = Workbook()
            sheet = wb.active
        else:
            wb = openpyxl.load_workbook(file_path)
            sheet = wb.active
        
        if applications:
            # Заголовки
            header = list(applications[0].keys())
            for col_idx, col_name in enumerate(header, 1):
                sheet.cell(row=1, column=col_idx, value=col_name)
            
            # Данные
            for row in applications:
                sheet.append([row.get(col, "") for col in header])
            
            wb.save(file_path)

            return True
            
    except Exception as e:
        return False
        
def order_number_req(file_path):
    try:
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook.active
        
        # Получаем все значения первого столбца, исключая пустые
        column_values = []
        for cell in sheet['A']:
            if cell.value is not None and cell.value != '№ п.п':  # Пропускаем заголовок
                column_values.append(cell.value)
        
        print(column_values)
        
        if not column_values:
            return 1
        
        last_value = column_values[-1]
        
        # Пробуем преобразовать в число (работает и с int, и со строками)
        try:
            numeric_value = float(last_value)
            return int(numeric_value) + 1
        except (ValueError, TypeError):
            return 1
            
    except (FileNotFoundError, Exception) as e:
        print(f"Ошибка: {e}")
        return 1
