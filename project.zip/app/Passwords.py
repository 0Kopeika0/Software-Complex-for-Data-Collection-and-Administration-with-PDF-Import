import bcrypt
import sqlite3
import os

def password_data():
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")

	conn = sqlite3.connect(file_path)
	c = conn.cursor()

	c.execute('''SELECT * FROM passwords''')
	rows = c.fetchall()

	conn.close()  # ✅ Закрываем соединение
	return rows
    
def delete_superdata_help(id_data):
	id_superdata = int(id_data)
	
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")

	conn = sqlite3.connect(file_path)
	c = conn.cursor()
	c.execute('DELETE FROM passwords WHERE id = ?', (id_superdata,))
	conn.commit()
	conn.close()

def add_superdata_help(login, password, indf):
    BASE_DIR = os.path.dirname(os.path.dirname(__file__))
    DATA_DIR = os.path.join(BASE_DIR, 'data')
    file_path = os.path.join(DATA_DIR, "BD.db")
    conn = sqlite3.connect(file_path)
    c = conn.cursor()
    
    # Хэшируем пароль один раз
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    
    # Проверяем существование записи (фиксируем и login, и indf)
    c.execute('SELECT id FROM passwords WHERE login = ? AND indf = ?', (login, indf))
    existing = c.fetchone()
    
    if existing:
        conn.close()  # Просто закрываем соединение
        return {"status": "error", "error": "Уже существует такая запись"}
    
    # Вставляем нового пользователя
    c.execute(
        'INSERT INTO passwords (login, password_hash, indf) VALUES (?, ?, ?)',
        (login, password_hash, indf)
    )
    
    conn.commit()
    conn.close()
    
    return {"status": "ok"}
	
def change_superadmin_help(login, password):
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	c = conn.cursor()
	
	password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
	
	c.execute('''DELETE FROM passwords_admin_system''')	
	c.execute('''INSERT INTO passwords_admin_system (login, password_hash) VALUES (?, ?)''', (login, password_hash))

	conn.commit()
	conn.close()
