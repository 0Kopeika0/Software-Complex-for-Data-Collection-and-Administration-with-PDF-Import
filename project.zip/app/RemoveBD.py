import sqlite3
import json
import os

def search_boss(conn, boss_data):
	c = conn.cursor()
	c.execute('''SELECT id_request, group_id
				FROM bosses 
				WHERE full_name = ? AND role_type = ?''', 
				(boss_data.get("full_name"), 
				 boss_data.get("role_type")))

	rows = c.fetchall()

	return rows
	    
def search_role_table(conn, role_table_data):
	c = conn.cursor()
	c.execute('''SELECT id_main_work
				FROM role_table 
				WHERE action = ? AND sid_mandant = ? AND functional_role = ?
				AND role_code = ? AND org_role = ?''', 
				(role_table_data.get("action"), 
				 role_table_data.get("sid_mandant"),
				 role_table_data.get("functional_role"),
				 role_table_data.get("role_code"),
				 role_table_data.get("org_role")))

	rows = c.fetchall()
	return [row[0] for row in rows]  # список id_main_work (не id_request!)
	
def search_main_work(conn, id_roles_table, main_work_data):
	c = conn.cursor()

	# Проверяем существование
	c.execute('''
		SELECT id_request FROM main_work 
		WHERE id_main_work = ? AND is_new_user = ? AND is_test_zone = ? 
		AND is_prod_zone = ? AND need_client_install = ? 
		AND is_arm_connect = ? AND is_arm_disconnect = ? 
		AND is_arm_change = ? AND is_ivs = ? AND is_evspd = ? 
		AND is_internet = ? AND note = ?
	''', (
		id_roles_table,
		int(main_work_data[0]),
		int(main_work_data[1]),
		int(main_work_data[2]),
		int(main_work_data[3]),
		int(main_work_data[4]),
		int(main_work_data[5]),
		int(main_work_data[6]),
		int(main_work_data[7]),
		int(main_work_data[8]),
		int(main_work_data[9]),
		main_work_data[10]
	))

	rows = c.fetchall()     # берет ВСЕ строки
	return [row[0] for row in rows]  # возвращает список всех ID
    
def search_applicant(conn, applicant_data):
	c = conn.cursor()

	c.execute('''
		SELECT id_person FROM person 
		WHERE last_name = ? AND first_name = ? AND middle_name = ? 
		AND position = ? AND email = ? AND phone = ?''', 
		(applicant_data[0], applicant_data[1], 
		applicant_data[2], applicant_data[3], applicant_data[4], applicant_data[5]))
	
	rows = c.fetchall()
	return [row[0] for row in rows]

def search_supervisor(conn, supervisor_data):
	c = conn.cursor()

	c.execute('''
        SELECT id_person FROM person 
        WHERE last_name = ? AND first_name = ? AND middle_name = ? 
        AND email = ? AND position IS NULL AND phone IS NULL''', 
		(supervisor_data[0], supervisor_data[1], 
		supervisor_data[2], supervisor_data[3]))
	
	rows = c.fetchall()
	return [row[0] for row in rows]  # список id_person  (не id_request!)
	
def search_request(conn, supervisor_data):
	c = conn.cursor()

	c.execute('''
		SELECT id_request FROM request 
		WHERE request_number = ? AND request_date = ? 
		AND computer_name = ? AND ip_address = ? AND access_basis = ?
	''', (supervisor_data[0], supervisor_data[1], supervisor_data[2],
	supervisor_data[3], supervisor_data[4]))

	rows = c.fetchall()
	return [row[0] for row in rows]
 
def removeBD(data):
	BASE_DIR = os.path.dirname(os.path.dirname(__file__))
	DATA_DIR = os.path.join(BASE_DIR, 'data')
	file_path = os.path.join(DATA_DIR, "BD.db")
	conn = sqlite3.connect(file_path)
	c = conn.cursor()

	# Передаем conn и данные в функцию
	officials = data["requests"][0]["officials"] 
	mas_id_officials = []
	for item in officials:
		id_off = search_boss(conn, item)
		mas_id_officials.append(id_off)
	
	common = set(mas_id_officials[0]).intersection(*map(set, mas_id_officials[1:]))
	id_officials = [i[0] for i in common]

	# Передаем conn и данные в функцию
	roles = data["requests"][0]["roles"]
	id_roles = search_role_table(conn, roles[0])
		
	main_work_data = []
	main_work_data.append(data["requests"][0]["main_work"]["is_new_user"])
	main_work_data.append(data["requests"][0]["main_work"]["is_test_zone"])
	main_work_data.append(data["requests"][0]["main_work"]["is_prod_zone"])
	main_work_data.append(data["requests"][0]["main_work"]["need_client_install"])
	main_work_data.append(data["requests"][0]["main_work"]["is_arm_connect"])
	main_work_data.append(data["requests"][0]["main_work"]["is_arm_disconnect"])
	main_work_data.append(data["requests"][0]["main_work"]["is_arm_change"])
	main_work_data.append(data["requests"][0]["main_work"]["is_ivs"])
	main_work_data.append(data["requests"][0]["main_work"]["is_evspd"])
	main_work_data.append(data["requests"][0]["main_work"]["is_internet"])
	main_work_data.append(data["requests"][0]["main_work"]["note"])

	id_main_work = []
	for i in id_roles:
		id_prom = search_main_work(conn, i, main_work_data)  # возвращает список [id1, id2, ...]
		id_main_work.extend(id_prom)  # добавляем все элементы

	applicant_data = []
	applicant_data.append(data["requests"][0]["applicant"]["last_name"])
	applicant_data.append(data["requests"][0]["applicant"]["first_name"])
	applicant_data.append(data["requests"][0]["applicant"]["middle_name"])
	applicant_data.append(data["requests"][0]["applicant"]["position"])
	applicant_data.append(data["requests"][0]["applicant"]["email"])
	applicant_data.append(data["requests"][0]["applicant"]["phone"])
	id_applicant_data = search_applicant(conn, applicant_data)

	c.execute('''
		SELECT id_request FROM person_in_request 
		WHERE id_person = ?''', (id_applicant_data[0],))

	rows = c.fetchall()
	id_request_applicant = [row[0] for row in rows]
		
	supervisor_data = []
	supervisor_data.append(data["requests"][0]["supervisor"]["last_name"])
	supervisor_data.append(data["requests"][0]["supervisor"]["first_name"])
	supervisor_data.append(data["requests"][0]["supervisor"]["middle_name"])
	supervisor_data.append(data["requests"][0]["supervisor"]["email"])
	id_supervisor_data = search_supervisor(conn, supervisor_data)
	
	c.execute('''
		SELECT id_request FROM person_in_request 
		WHERE id_person = ?''', (id_applicant_data[0],))

	rows = c.fetchall()
	id_request_supervisor = [row[0] for row in rows]
	
	request_data = []
	request_data.append(data["requests"][0]["request"]["request_number"])
	request_data.append(data["requests"][0]["request"]["request_date"])
	request_data.append(data["requests"][0]["request"]["computer_name"])
	request_data.append(data["requests"][0]["request"]["ip_address"])
	request_data.append(data["requests"][0]["request"]["access_basis"])
	id_request_data = search_request(conn, request_data)
		
	common_ids = list(
		set(id_request_applicant) & 
		set(id_request_supervisor) & 
		set(id_officials) & 
		set(id_main_work) & 
		set(id_request_data)
	)
	
	id_request = common_ids[0]
	
	#Ищем людей
	#-------------------------------------------#
	c.execute('''SELECT id_person FROM person_in_request WHERE id_request = ?''', (id_request,))
	results = c.fetchall()  # список кортежей [(id1,), (id2,), ...]

	person_ids = [row[0] for row in results]  # список чисел
	#print(f"Эти ID_person надо удалить: {person_ids}")
	
	# Просто количество, без получения самих id
	c.execute('''SELECT COUNT(*) FROM person_in_request WHERE id_person = ?''', (person_ids[0],))
	count_apl = c.fetchone()[0]  # количество
	#print(f"Это количество ID_perdon_apl: {count_apl}")
	
	
	# Просто количество, без получения самих id
	c.execute('''SELECT COUNT(*) FROM person_in_request WHERE id_person = ?''', (person_ids[1],))
	count_ser = c.fetchone()[0]  # количество
	#print(f"Это количество ID_perdon_ser: {count_ser}")
	#-------------------------------------------#

	c.execute('''SELECT id_org FROM request WHERE id_request = ?''', (id_request,))
	id_org = c.fetchone()
	c.execute('''SELECT COUNT(*) FROM request WHERE id_org = ?''', (id_org[0],))
	org_count = c.fetchone()[0]

	conn.execute("PRAGMA foreign_keys = ON")  # ОБЯЗАТЕЛЬНО!
	
	if org_count == 1:
		# У организации только одна заявка - удаляем организацию (CASCADE удалит заявку)
		c.execute('''DELETE FROM organization WHERE id_org = ?''', (id_org[0],))
	else:
		# У организации есть другие заявки - удаляем только эту заявку
		c.execute('''DELETE FROM request WHERE id_request = ?''', (id_request,))
		
	if count_apl == 1:
	   c.execute('''DELETE FROM person WHERE id_person = ?''', (person_ids[0],))
	   
	if count_ser == 1:
	   c.execute('''DELETE FROM person WHERE id_person = ?''', (person_ids[1],))
   
	conn.commit()
	conn.close()  # не забывай закрывать соединение
