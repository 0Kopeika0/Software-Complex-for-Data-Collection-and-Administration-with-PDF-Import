import json
import os
import re
from datetime import datetime
import easyocr
import numpy as np
import pdfminer.high_level
from Levenshtein import ratio
from pdf2image import convert_from_path
from WriteFile import writeFile

def clean_text(text):
    """Очищает текст от мусора и кракозябр"""
    if not text:
        return ""
    
    text = re.sub(r'[^А-Яа-я0-9\s\.\-\@\+\(\)\/]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip() #заменяет лючое количество пробелов на 1
    
    return text


def find_text(blocks, coords):
    x1_area, y1_area, x2_area, y2_area = coords
    
    result = []
    for item in blocks:
        box = item[0]
        x1 = int(box[0][0])
        y1 = int(box[0][1])
        x2 = int(box[2][0])
        y2 = int(box[2][1])
        
        if (x2 >= x1_area and x1 <= x2_area and y2 >= y1_area and y1 <= y2_area):
            result.append(item)

    if not result:
        return []
    else:
        result.sort(key=lambda x: (x[0][0][1], x[0][0][0]))
		
        flag = None
        stroka = ''
        data = []
        
        for i, item in enumerate(result):        
            chto = item[0][0]
            value = clean_text(item[1])
            
            if flag:
                if abs(flag - chto[1]) < 15:
                    stroka = stroka + ' ' + value
                else:
                    data.append(stroka)
                    stroka = value
                    flag = chto[1]
            else:
                flag = chto[1]
                stroka = value
    
    # Добавляем последнюю строку
    if stroka:
        data.append(stroka)
    
    return data
    	
    
def value_text(stroka, keywords_start, keywords_finish = None, pr = None, threshold = 0.65, param = 0.5):
	mas_str = stroka.split()
	start = keywords_start.split()
	
	if keywords_finish:
		finish = keywords_finish.split()
	
	flag = False
	mas_flag = []
	
	'''
	if pr is not None:
		print()
		print(f"stroka = {stroka} и keywords_start = {keywords_start}")
	'''

	if len(start) == 1:
		for i, item in enumerate(mas_str):
			if ratio(start[0].lower(), item.lower()) >= threshold:
				res = mas_str[i+1:]
				flag = True
				break
	else:
		for i in range(len(mas_str) - len(start) + 1):
			mas_flag = [] 
			for j in range(len(start)):			
				
				'''
				if pr is not None:
					print()
					print(f"    start = {start[j]} и mas_str = {mas_str[i+j]}")
				'''

				if ratio(start[j].lower(), mas_str[i+j].lower()) >= threshold:
					mas_flag.append(True)
				else:
					mas_flag.append(False)
					
			if (sum(mas_flag) / len(mas_flag)) >= param:			
				res = mas_str[i+len(start):]
				
				'''
				if pr is not None:	
					print(f"    res = {res}")
				'''
				
				flag = True
				break	
		
	if flag:
		if keywords_finish:
			for i, item in enumerate(res):
				for val in finish:
					if ratio(val.lower(), item.lower()) >= threshold:
						result = res[:i]
						return ' '.join(result)
						
		return ' '.join(res)
	else:
		return ''
		
def find_coords_key(blocks, coords, key, threshold = 0.9):
	x1_area, y1_area, x2_area, y2_area = coords
	result = []
	for item in blocks:
		box = item[0]
		x1 = int(box[0][0])
		y1 = int(box[0][1])
		x2 = int(box[2][0])
		y2 = int(box[2][1])
		
		if (x2 >= x1_area and x1 <= x2_area and y2 >= y1_area and y1 <= y2_area):
			result.append(item)

	if not result:
		return []

	for item in result:
		text = item[1]
		if ratio(clean_text(text.lower()), clean_text(key.lower())) >= threshold:
			return [item[0], item[1]]

	return []
		
def value_text_keywords_false(mas, key_false, key_fall, threshold = 0.65):
	res = []
	
	if key_false:
		keywords_false = key_false.split()
		
	if key_fall:
		keywords_fall = key_fall.split()	
	
	for i, item in enumerate(mas):
		m = [clean_text(l) for l in item.split()]
		flag = False
		
		for j in m:
			for k, val in enumerate(keywords_false):
				if ratio(j.lower(), val.lower()) >= threshold:
					
					'''
					if pr is not None:
						print()
						print(f"    j.lower() = {j.lower()} и mas_str = {val.lower()} и вердикт = {ratio(j.lower(), val.lower())}")
					'''
					
					flag = True
					break
			
			if flag:
				break
		
		if not flag:
			res.append(item)
	
	result = []
	for i, item in enumerate(res):
		m = item.split()
		for j in m:
			is_bad = False
			for val in keywords_fall:
				if ratio(j.lower(), val.lower()) >= threshold:
					is_bad = True
					break
			if not is_bad:
				result.append(j)
	
	return ' '.join(result)

def cooeds_role_data(result, h, w):
	coords = {
		"block15": (int(300*w/1653), int(790*h/2339), int(2200*w/1653), int(1100*h/2339)),
	}

	mas_coords = {}

	numer_role = find_coords_key(result, coords["block15"], "Удалить")
	add_remove_role = find_coords_key(result, coords["block15"], "Мандант")
	SID_MANDANT_role = find_coords_key(result, coords["block15"], "роль/Бизнес-роль")
	kod_role = find_coords_key(result, coords["block15"], "Код роли")
	object_role = find_coords_key(result, coords["block15"], "Объект полномочий")
	
	if not(numer_role or add_remove_role or SID_MANDANT_role or kod_role or object_role):
		return []
	
	if numer_role:
		points = numer_role[0]
		mas_coords["add_remove_role"] = [
			points[2][0], points[2][1],  # нижняя правая (x, y)
			points[3][0], points[3][1]   # нижняя левая (x, y)
		]
	if add_remove_role:
		points = add_remove_role[0]
		mas_coords["SID_MANDANT_role"] = [points[2][0], points[2][1], points[3][0], points[3][1]]
	if SID_MANDANT_role:
		points = SID_MANDANT_role[0]
		mas_coords["function_role"] = [points[2][0], points[2][1], points[3][0], points[3][1]]
	if kod_role:
		points = kod_role[0]
		mas_coords["kod_role"] = [points[2][0], points[2][1], points[3][0], points[3][1]]
	if object_role:
		points = object_role[0]
		mas_coords["object_role"] = [points[2][0], points[2][1], points[3][0], points[3][1]]
	
	for key in mas_coords.keys():
		mas_coords[key] = [int(x) for x in mas_coords[key]]

	#print(mas_coords)
	
	y_sr = 0
	for key in mas_coords.keys():
		if mas_coords[key][3] > y_sr:
			y_sr = mas_coords[key][3]
	#print(y_sr)
	
	full_keys = {
		"add_remove_role": "Дополнительные параметры",
		"SID_MANDANT_role": "Дополнительные параметры  Мандант ",
		"function_role": "Дополнительные параметры  роль/Бизнес-роль",
		"kod_role": "Дополнительные параметры Код роли",
		"object_role": "Дополнительные параметры Объект полномочий",
	}	
	
	elem = []
	elem1 = []
	elem2 = []
	
	elem_flag1 = {
		"add_remove_role": False,
		"SID_MANDANT_role": False,
		"function_role": False,
		"kod_role": False,
		"object_role": False,
	}
	
	elem_flag2 = {
		"add_remove_role": False,
		"SID_MANDANT_role": False,
		"function_role": False,
		"kod_role": False,
		"object_role": False,
	}
	for key in mas_coords.keys():
		mas_coords[key] = [
			int((mas_coords[key][0]) * w / 1653), 
			int((mas_coords[key][1] - 2) * h / 2339), 
			int((mas_coords[key][2]) * w / 1653), 
			int((mas_coords[key][3] + 100) * h / 2339)
		]  
		res = find_text(result, tuple(mas_coords[key]))
	
		keywords_fall = full_keys[key].split()	
		
		r = []	
		for i, item in enumerate(res):
			m = item.split()
			for j in m:
				is_bad = False
				for val in keywords_fall:
					if ratio(j.lower(), val.lower()) >= 0.7:
						is_bad = True
						break
				if is_bad:
					break
			if not is_bad:
				r.append(item)
		
		if r:
			if len(r) == 1:
				elem1.append(r[0])
				elem2.append('')
				elem_flag1[key] = True
			if len(r) >= 2:
				elem1.append(r[0])
				elem2.append(r[1])
				elem_flag1[key] = True
				elem_flag2[key] = True
		else:
			elem1.append('')
			elem2.append('')	
		
	# Безопаснее с проверкой
	elem.append({
		"action": elem1[0] if len(elem1) > 0 and elem_flag1["add_remove_role"] == True  else "",
		"sid_mandant": elem1[1] if len(elem1) > 1 and elem_flag1["SID_MANDANT_role"] == True else "",
		"functional_role": elem1[2] if len(elem1) > 2 and elem_flag1["function_role"] == True else "",
		"role_code": elem1[3] if len(elem1) > 3 and elem_flag1["kod_role"] == True else "",
		"org_role": elem1[4] if len(elem1) > 4 and elem_flag1["object_role"] == True else "",
	})
		
	# Безопаснее с проверкой
	elem.append({
		"action": elem2[0] if len(elem1) > 0  and elem_flag1["add_remove_role"] == True else "",
		"sid_mandant": elem2[1] if len(elem1) > 1 and elem_flag1["SID_MANDANT_role"] == True else "",
		"functional_role": elem2[2] if len(elem1) > 2 and elem_flag1["function_role"] == True else "",
		"role_code": elem2[3] if len(elem1) > 3 and elem_flag1["kod_role"] == True else "",
		"org_role": elem2[4] if len(elem1) > 4 and elem_flag1["object_role"] == True else "",
	})

	return elem

def answer_yes_no(stroka, threshold=0.75):
    flag_yes = False
    flag_no = False
    
    mas_str = stroka.split()
    for value in mas_str:
        if ratio(value.lower(), "да") >= threshold:
            flag_yes = True
        if ratio(value.lower(), "нет") >= threshold:
            flag_no = True
    
    # Если есть оба или нет ни одного
    if (flag_yes and flag_no) or (not flag_yes and not flag_no):
        return ""
    elif flag_yes:
        return 1
    elif flag_no:  # flag_no
        return 0
    else:
        return ""
        
def text_coords(result, coord, key, koef, koef_y = 0):
	coo = find_coords_key(result, coord , key)
	if coo:
		# coo[0] - это список из 4 точек
		points = coo[0]

		# Верхний левый угол (первая точка)
		x_left = points[0][0]
		y_top = points[0][1]

		# Нижний правый угол (третья точка)
		x_right = points[2][0]
		y_bottom = points[2][1]

		text = find_text(result, (x_left, y_top, x_right + (x_right - x_left)*koef, y_bottom + (y_bottom - y_top)*koef_y))
		
		return text
	return ''

def pdfFile(file_name):
	request_data = {
				"organization": {"org_name": "", "department": "", "address": ""},
				"request": {"iys": "", "request_number": "", "request_date": "", "computer_name": "", "ip_address": "", "access_basis": ""},
				"applicant": {"last_name": "", "first_name": "", "middle_name": "", "position": "", "email": "", "phone": ""},
				"supervisor": {"email": "", "last_name": "", "first_name": "", "middle_name": ""},
				"main_work": {
					"is_new_user": "", "is_test_zone": "", "is_prod_zone": "", "note": "",
					"need_client_install": "", "is_arm_connect": "", "is_arm_disconnect": "",
					"is_arm_change": "", "is_ivs": "", "is_evspd": "", "is_internet": ""
				},
				"roles": [],
				"officials": [
					{"full_name": "", "role_type": "admin_arm"},
					{"full_name": "", "role_type": "aib"},
					{"full_name": "", "role_type": "contact_center"},
					{"full_name": "", "role_type": "security"},
					{"full_name": "", "role_type": "owner"}
				]
			}

	keywords_finish = {
		"org_name": "фамилия",
		"department": "имя",
		"address": "(населенный",
		"applicant_middle_name": "должность",
		
		"request_number": "дата", 
		"computer_name": "оля ( ИВС",
		"ip_address": "Р адрес",
			
		"applicant_email": "телефон",
		"applicant_phone": "Е-щай с а @щай и",
		"applicant_position": "отчество",

		"admin_arm_full_name": "(дата, подпись) ФИО",
		"admin_aib_full_name": "(дата, подпись) ФИО",
		"contact_center_full_name": "(дата, подпись) ФИО (ал одиись) (ФИО)",
		"security_full_name": "(дата, подпись) ФИО",
		"owner_full_name": "(дата, подпись) ФИО ()аш  по-иись)",
	}

	keywords_start = {
		"org_name": "организация",
		"department": "подразделение",
		"address": "рабочего места адрес",
		
		"request_number": "заявки", 
		"request_date": "дата заполнения заявки", 
		"ip_address": "рабочего места", 
		"access_basis": "основание для организации доступа",
		"computer_name": "имя компьютера", 
		
		"applicant_last_name": "фамилия",
		"applicant_first_name": "имя",
		"applicant_middle_name": "отчество",
		"applicant_position": "должность",
		"applicant_email": "Е-щай",
		"applicant_phone": "телефон",
		
		"admin_arm_full_name": "Администратор АРМ",
		"admin_aib_full_name": "АИБ",
		"contact_center_full_name": "Контакт-центр ООО Газпром информ",
		"owner_full_name": "Владелец информационного ресурса",
		
		"is_ivs": "ИВС",
		"note": "дополнительные параметры",
		
	}

	keywords_false = {
		"security_full_name": "Согласовано Контакт-центр ООО информ Владелец информационного ресурса", 
		"admin_arm": "АИБ Рабочее место Требованиям настройкам защиты рабочих мест сетевой доступ предост авлен коммерческую тайну составляющей иной конфиденциальной информации перечнем",
		"admin_aib": "Администратор АРМ Рабочее место Требованиям настройкам защиты рабочих мест сетевой доступ предост авлен коммерческую тайну составляющей иной конфиденциальной информации перечнем",
		"supervisor_name": "постоянной Зона Основания для организации доступа Раздел 2. Системные реквизиты Новый пользователь ФИО Установка клиентской части",
		"supervisor_email": "Основания для организации доступа Раздел 2. Системные реквизиты Новый пользователь Е-Ма1 Установка клиентской части адрес рабочего места",
		"is_new_user": "раздел 2 системные реквизиты установка клиенской части зона тестирования зона постоянной эксплуатации",
		"need_client_install": " раздел 2 системные требования зона тестирования зона постоянной эксплуатации новый пользователь",
		"is_test_zone": "Новый пользователь постоянной эксплуатации", 
		"is_prod_zone": "Новый пользователь тестирования",
		"is_arm_connect": "Раздел рабочего места отключение расположение ИВС",
		"is_arm_disconnect": "подключение изменение условий ИВС ЕВСПД рабочего места",
		"is_arm_change": "Интернет Подключение рабочего места отключение ЕВСПД",
		"is_internet": "Изменение условий подключения АРМ ЕВСПД по настройкам и мерам защиты рабочих мест сетевой доступ предоставлен требованиям",	
		"is_evspd": "ИВС Интернет Отключение АРМ Изменение условий подключения требованиям по настройкам и меры защиты рабочих мест сетевой доступ",
		"iys": "Дата заполнения",
		"owner_full_name": "Руководитель структурного подразделения Контакт-центр ООО Центр кибербезопасности службы корпоративной защиты",
		"address": "Телефон  Ещай @ имя компьютера IP рабочего места Е-па Отчество Должность",
		"applicant_middle_name":"Дата заполнения заявки  Имя телефон фамилия адрес есщай ещая Е-па населенный пункш улцца дом номер комнашы",
		"ip_address": "(населснкый пункт номср колнаты) Имя компьютера (Эля ИВС) Основание для организации доступа Новый пользователь Е-Май непосредственного руководителя пользователя Ф ИО. непосредственного руководителя пользователя",
	}

	keywords_fall = {
		"security_full_name": "Центр кибербезопасности Службы корпоративной защиты ПАО Газпром (дата, подпись) (ФИО) (дал", 
		"admin_arm": "Администратор АРМ (Эаш подпись) (ФИО) Е-шй (Е-пЙ ( )",
		"admin_aib": "АИБ (Эаш подпись) (ФИО) Е-шй (Е-пЙ ( )",
		"supervisor_name": "Основания для организации доступа Раздел 2. Системные реквизиты Новый пользователь ФИО",
		"supervisor_email": "Основания для организации доступа Раздел 2. Системные реквизиты Новый пользователь Е-Ма1 ФИО непосредственного руководителя Зона тестирования Зона постоянной",
		"is_new_user": "новый пользователь",
		"need_client_install": "установка клиенской части",
		"is_test_zone": "Зона тестирования", 
		"is_prod_zone": "Зона постоянной эксплуатации",
		"is_arm_connect": "Подключение нового АРМ",
		"is_arm_disconnect": "Отключение АРМ",
		"is_arm_change": "Изменение условий подключения АРМ",
		"is_internet": "Интернет",	
		"is_evspd": "ЕВСПД",
		"iys": "Индивидуальная заявка доступ пользователя к ИР ИУС указать назсание ИУС на Раздел 1. Данные",
		"owner_full_name": "СОГЛАСОВАНО (даша подпцсь) (ФИО) (даша под чсь) (ФИО) Владелец информационного ресурса",
		"address": "(населенный пункш улцца дом номер комнашы) адрес",
		"applicant_middle_name":"отчество",
		"ip_address": "Р адрес рабочего места",
	}
	
	# Конвертируем ОДИН раз ДО цикла
	images = convert_from_path(file_name, dpi=200)
	total_pages = len(images)  # Можно даже не использовать PdfReader

	for i in range(total_pages):
		image_np = np.array(images[i])  # Берем страницу из уже загруженных
		
		reader = easyocr.Reader(['ru'], gpu=False)
		result = reader.readtext(image_np)
		
		h, w = image_np.shape[:2]
		document_bounds = (0, 0, w, h)
		
		coords = {
			"block1": (int(300*w/1653), int(200*h/2339), int(2200*w/1653), int(700*h/2339)),
			"block2": (int(300*w/1653), int(1850*h/2339), int(2200*w/1653), int(2200*h/2339)),
			"block3": (int(300*w/1653), int(2000*h/2339), int(2200*w/1653), int(2050*h/2339)),
			"block4": (int(300*w/1653), int(1270*h/2339), int(2200*w/1653), int(1350*h/2339)),
			"block5": (int(300*w/1653), int(600*h/2339), int(550*w/1653), int(750*h/2339)),
			"block6": (int(600*w/1653), int(600*h/2339), int(2200*w/1653), int(750*h/2339)),
			"block7": (int(300*w/1653), int(750*h/2339), int(2200*w/1653), int(1300*h/2339)),
			"block8": (int(300*w/1653), int(750*h/2339), int(800*w/1653), int(800*h/2339)),
			"block9": (int(1000*w/1653), int(750*h/2339), int(2200*w/1653), int(800*h/2339)),
			"block10": (int(300*w/1653), int(790*h/2339), int(800*w/1653), int(850*h/2339)),
			"block101": (int(500*w/1653), int(790*h/2339), int(800*w/1653), int(850*h/2339)),
			"block11": (int(300*w/1653), int(1080*h/2339), int(600*w/1653), int(1160*h/2339)),
			"block12": (int(800*w/1653), int(1080*h/2339), int(900*w/1653), int(1160*h/2339)),
			"block13": (int(1000*w/1653), int(1080*h/2339), int(2200*w/1653), int(1160*h/2339)),
			"block14": (int(1000*w/1653), int(1160*h/2339), int(1600*w/1653), int(1210*h/2339)),
			"block16": (int(820*w/1653), int(1160*h/2339), int(900*w/1653), int(1210*h/2339)),
			"block17": (int(300*w/1653), int(50*h/2339), int(2200*w/1653), int(250*h/2339)),
			"block18": (int(300*w/1653), int(400*h/2339), int(2200*w/1653), int(500*h/2339)),
			"block19": (int(1000*w/1653), int(250*h/2339), int(2200*w/1653), int(450*h/2339)),
			"block20": (int(300*w/1653), int(500*h/2339), int(2200*w/1653), int(600*h/2339)),
		}
    
		role_data = cooeds_role_data(result, h, w)
		if role_data:
			request_data["roles"] = role_data
			#print(f"Таблица ролей = {role_data}")
			
		text17 = find_text(result, coords["block17"])	
		iys = value_text_keywords_false(text17, keywords_false["iys"], keywords_fall["iys"])
		if iys:
			request_data["request"]['iys'] = iys
			
		if request_data["organization"]['address'] == '':
			text18 = find_text(result, coords["block18"])
			address = value_text_keywords_false(text18, keywords_false["address"], keywords_fall["address"])
			if address:
				request_data["organization"]['address'] = address
				#print(f"Адрес = {address}")
				
		if request_data["applicant"]['middle_name'] == '':
			text19 = find_text(result, coords["block19"])
			applicant_middle_name = value_text_keywords_false(text19, keywords_false["applicant_middle_name"], keywords_fall["applicant_middle_name"])
			if applicant_middle_name:
				request_data["applicant"]['middle_name'] = applicant_middle_name
				#print(f"Отчество = {applicant_middle_name}")

		if request_data["request"]['ip_address'] == '':
			text20 = find_text(result, coords["block20"])
			ip_address = value_text_keywords_false(text20, keywords_false["ip_address"], keywords_fall["ip_address"])
			if ip_address:
				request_data["request"]['ip_address'] = ip_address
		
		text1 = find_text(result, coords["block1"])
		for i, item in enumerate(text1):
		#----------------------------------------------------------------------------------------------#
			#applicant	
			
			if i in [0, 1, 2, 3, 4] and request_data["applicant"]['last_name'] == '':
				applicant_last_name = value_text(item, keywords_start["applicant_last_name"])
				if applicant_last_name:
					request_data["applicant"]['last_name'] = applicant_last_name
					#print(f"Фамилия = {applicant_last_name}")
					
			if i in [1, 2, 3, 4, 5] and request_data["applicant"]['first_name'] == '':
				applicant_first_name = value_text(item, keywords_start["applicant_first_name"])
				if applicant_first_name:
					request_data["applicant"]['first_name'] = applicant_first_name
					#print(f"Имя = {applicant_first_name}")

			if i in [2, 3, 4, 5, 6] and request_data["applicant"]['position'] == '':
				applicant_position = value_text(item, keywords_start["applicant_position"], keywords_finish["applicant_position"])
				if applicant_position:
					request_data["applicant"]['position'] = applicant_position
					#print(f"Должность = {applicant_position}")

			if i in [3, 4, 5, 6, 7] and request_data["applicant"]['email'] == '':
				applicant_email = value_text(item, keywords_start["applicant_email"], keywords_finish["applicant_email"])
				if applicant_email:
					request_data["applicant"]['email'] = applicant_email
					#print(f"Email = {applicant_email}")

			if i in [3, 4, 5, 6, 7] and request_data["applicant"]['phone'] == '':
				applicant_phone = value_text(item, keywords_start["applicant_phone"], keywords_finish["applicant_phone"])
				if applicant_phone:
					request_data["applicant"]['phone'] = applicant_phone
					#print(f"Телефон = {applicant_phone}")	
			
			#applicant
			#----------------------------------------------------------------------------------------------#
			
			#----------------------------------------------------------------------------------------------#
			#organization
			
			if i in [0, 1, 2, 3, 4] and request_data["organization"]['org_name'] == '':
				org_name = value_text(item, keywords_start["org_name"], keywords_finish["org_name"])
				if org_name:
					request_data["organization"]['org_name'] = org_name
					#print(f"Организация = {org_name}")
					
			if i in [1, 2, 3, 4, 5] and request_data["organization"]['department'] == '':
				department = value_text(item, keywords_start["department"], keywords_finish["department"])
				if department:
					request_data["organization"]['department'] = department
					#print(f"Подразделение = {department}")
			
			#organization
			#----------------------------------------------------------------------------------------------#
			
			#----------------------------------------------------------------------------------------------#
			#request
			
			if i in [0, 1, 2] and request_data["request"]['request_number'] == '':
				request_number = value_text(item, keywords_start["request_number"], keywords_finish["request_number"])
				if request_number:
					request_data["request"]['request_number'] = request_number
					#print(f"№ заявки = {request_number}")
					
			if i in [0, 1, 2] and request_data["request"]['request_date'] == '':
				request_date = value_text(item, keywords_start["request_date"])
				if request_date:
					request_data["request"]['request_date'] = request_date
					#print(f"Дата заполнения заявки = {request_date}")

			if i in [5, 6, 7, 8, 9] and request_data["request"]['computer_name'] == '':
				computer_name = value_text(item, keywords_start["computer_name"], keywords_finish["computer_name"])
				if computer_name:
					request_data["request"]['computer_name'] = computer_name
					#print(f"Имя компьютера = {computer_name}")

			if i in [7, 8, 9, 10, 11] and request_data["request"]['access_basis'] == '':
				access_basis = value_text(item, keywords_start["access_basis"])
				if access_basis:
					request_data["request"]['access_basis'] = access_basis
					#print(f"Основание для организации доступа = {access_basis}")
			#request
			#----------------------------------------------------------------------------------------------#

		if request_data["officials"][2]['full_name'] == '':
			text2 = find_text(result, coords["block2"])
			for i, item in enumerate(text2):
				if i in [1, 2, 3, 4] and request_data["officials"][2]['full_name'] == '':
					contact_center_full_name = value_text(item, keywords_start["contact_center_full_name"], keywords_finish["contact_center_full_name"])
					if contact_center_full_name:
						request_data["officials"][2]['full_name'] = contact_center_full_name
						#print(f'Контакт-центр ООО "Газпром информ" = {contact_center_full_name}')
				
		if request_data["officials"][4]['full_name'] == '':
			owner_full_name = value_text_keywords_false(text2, keywords_false["owner_full_name"], keywords_fall["owner_full_name"])
			if owner_full_name:
				request_data["officials"][4]['full_name'] = owner_full_name					
				#print(f'Владелец информационного ресурса = {owner_full_name}')

		if request_data["officials"][3]['full_name'] == '':
			text3 = find_text(result, coords["block3"])
			security_full_name = value_text_keywords_false(text3, keywords_false["security_full_name"], keywords_fall["security_full_name"])
			if security_full_name:
				request_data["officials"][3]['full_name'] = security_full_name
				#print(f'Центр кибербезопасности. Службы корпоративной защиты ПАО "Газпром" = {security_full_name}')
		
		if request_data["officials"][0]['full_name'] == '':
			text4 = find_text(result, coords["block4"])
			admin_arm = value_text_keywords_false(text4, keywords_false["admin_arm"], keywords_fall["admin_arm"])
			if admin_arm:
				request_data["officials"][0]['full_name'] = admin_arm
				#print(f'Администратор АРМ = {admin_arm}')
		
		if request_data["officials"][1]['full_name'] == '':
			admin_aib = value_text_keywords_false(text4, keywords_false["admin_aib"], keywords_fall["admin_aib"])
			if admin_aib:
				request_data["officials"][1]['full_name'] = admin_arm
				#print(f'АИБ = {admin_aib}')

		if request_data["supervisor"]['email'] == '':
			text5 = find_text(result, coords["block5"])
			print(f"text5 = {text5}")
			supervisor_email = value_text_keywords_false(text5, keywords_false["supervisor_email"], keywords_fall["supervisor_email"])
			if supervisor_email:
				request_data["supervisor"]['email'] = supervisor_email
				#print(f'Начальник Email = {supervisor_email}')

		if request_data["supervisor"]['last_name'] == '':
			text6 = find_text(result, coords["block6"])
			print(f"text6 = {text6}")
			supervisor_name = value_text_keywords_false(text6, keywords_false["supervisor_name"], keywords_fall["supervisor_name"])
			if supervisor_name:
				name_super = supervisor_name.split()
				if len(name_super) == 1:
					request_data["supervisor"]['last_name'] = name_super[0]
				elif len(name_super) == 2:
					request_data["supervisor"]['last_name'] = name_super[0]
					request_data["supervisor"]['first_name'] = name_super[1]
				else:
					request_data["supervisor"]['last_name'] = name_super[0]
					request_data["supervisor"]['first_name'] = name_super[1]
					request_data["supervisor"]['middle_name'] = name_super[2]
				#print(f'Начальник ФИО = {supervisor_name}')
		
		if request_data["main_work"]['note'] == '' or request_data["main_work"]['is_ivs'] == '':
			text7 = find_text(result, coords["block7"])
			for i, item in enumerate(text7):
				if i in [10, 11, 12, 13, 14] and request_data["main_work"]['note'] == '':
					note = value_text(item, keywords_start["note"])
					if note:
						request_data["main_work"]['note'] = note
						#print(f"Дополнительные параметры = {note}")

				if i in [15, 16, 17, 18, 19, 20, 21] and request_data["main_work"]['is_ivs'] == '':
					is_ivs = value_text(item, keywords_start["is_ivs"])
					if is_ivs:
						request_data["main_work"]['is_ivs'] = answer_yes_no(is_ivs.lower())
						#print(f"ИВС = {answer_yes_no(is_ivs.lower())}")
		
		if request_data["main_work"]['is_new_user'] == '':
			text8 = text_coords(result, (int(300*w/1653), int(400*h/2339), int(1700*w/1653), int(1200*h/2339)) ,'Новый пользователь', 0.28)
			if not text8:
				text8 = find_text(result, coords["block8"])

			is_new_user = value_text_keywords_false(text8, keywords_false["is_new_user"], keywords_fall["is_new_user"])
			if is_new_user:
				request_data["main_work"]['is_new_user'] = answer_yes_no(is_new_user.lower())
				#print(f'Новый пользователь = {answer_yes_no(is_new_user.lower())}')

		if request_data["main_work"]['need_client_install'] == '':
			text9 = text_coords(result, (int(700*w/1653), int(500*h/2339), int(2200*w/1653), int(1200*h/2339)) ,'Установка клиенской части', 0.26)
			if not text9:
				text9 = find_text(result, coords["block9"])

			need_client_install = value_text_keywords_false(text9, keywords_false["need_client_install"], keywords_fall["need_client_install"])
			if need_client_install:
				request_data["main_work"]['need_client_install'] = answer_yes_no(need_client_install.lower())
				#print(f'Установка клиенской части = {answer_yes_no(need_client_install.lower())}')

		if request_data["main_work"]['is_test_zone'] == '':
			text10 = text_coords(result, (int(300*w/1653), int(500*h/2339), int(1500*w/1653), int(1200*h/2339)) ,'Зона тестирования', 0.29)
			if not text10:
				text10 = find_text(result, coords["block10"])
				
			is_test_zone = value_text_keywords_false(text10, keywords_false["is_test_zone"], keywords_fall["is_test_zone"])
			if is_test_zone:
				request_data["main_work"]['is_test_zone'] = answer_yes_no(is_test_zone.lower())
				#print(f'Зона тестирования = {answer_yes_no(is_test_zone.lower())}')

		if request_data["main_work"]['is_prod_zone'] == '':
			text101 = text_coords(result, (int(300*w/1653), int(500*h/2339), int(1800*w/1653), int(1500*h/2339)) ,'постоянной эксплуатации', 0.235)
			if not text101:
				text101 = find_text(result, coords["block101"])
				#print(text101)
				
			is_prod_zone = value_text_keywords_false(text101, keywords_false["is_prod_zone"], keywords_fall["is_prod_zone"])
			if is_prod_zone:
				request_data["main_work"]['is_prod_zone'] = answer_yes_no(is_prod_zone.lower())
				#print(f'Зона постоянной эксплуатации = {answer_yes_no(is_prod_zone.lower())}')

		if request_data["main_work"]['is_arm_connect'] == '':
			text11 = text_coords(result, (int(300*w/1653), int(300*h/2339), int(900*w/1653), int(3100*h/2339)) ,'Подключение нового АРМ', 0.27)
			if not text11:
				text11 = find_text(result, coords["block11"])
				
			is_arm_connect = value_text_keywords_false(text11, keywords_false["is_arm_connect"], keywords_fall["is_arm_connect"], threshold = 0.9)
			if is_arm_connect:
				request_data["main_work"]['is_arm_connect'] = answer_yes_no(is_arm_connect.lower())
				#print(f'Подключение нового АРМ = {answer_yes_no(is_arm_connect.lower())}')
		
		if request_data["main_work"]['is_arm_disconnect'] == '':
			text12 = text_coords(result, (int(300*w/1653), int(300*h/2339), int(900*w/1653), int(3100*h/2339)) ,'Отключение АРМ', 0.65)
			if not text12:
				text12 = find_text(result, coords["block12"])
				
			is_arm_disconnect = value_text_keywords_false(text12, keywords_false["is_arm_disconnect"], keywords_fall["is_arm_disconnect"], threshold = 0.9)
			if is_arm_disconnect:
				request_data["main_work"]['is_arm_disconnect'] = answer_yes_no(is_arm_disconnect.lower())
				#print(f'Отключение АРМ = {answer_yes_no(is_arm_disconnect.lower())}')

		if request_data["main_work"]['is_arm_change'] == '':
			text13 = text_coords(result, (int(300*w/1653), int(300*h/2339), int(900*w/1653), int(3100*h/2339)),'Изменение условий подключения АРМ', 0, 4)
			if not text13:
				text13 = find_text(result, coords["block13"])

			is_arm_change = value_text_keywords_false(text13, keywords_false["is_arm_change"], keywords_fall["is_arm_change"], threshold = 0.9)
			if is_arm_change:
				request_data["main_work"]['is_arm_change'] = answer_yes_no(is_arm_change.lower())
				#print(f'Изменение АРМ = {answer_yes_no(is_arm_change.lower())}')

		if request_data["main_work"]['is_internet'] == '':
			text14 = text_coords(result, (int(300*w/1653), int(300*h/2339), int(900*w/1653), int(3100*h/2339)) ,'Интернет', 0, 4)
			if not text14:
				text14 = find_text(result, coords["block14"])

			is_internet = value_text_keywords_false(text14, keywords_false["is_internet"], keywords_fall["is_internet"], threshold = 0.9)
			if is_internet:
				request_data["main_work"]['is_internet'] = answer_yes_no(is_internet.lower())
				#print(f'Интернет = {answer_yes_no(is_internet.lower())}')
		
		if request_data["main_work"]['is_evspd'] == '':
			text16 = text_coords(result, (int(300*w/1653), int(300*h/2339), int(900*w/1653), int(3100*h/2339)) ,'ЕВСПД', 0, 4)
			if not text16:
				text16 = find_text(result, coords["block16"])

			text16 = find_text(result, coords["block16"])
			is_evspd = value_text_keywords_false(text16, keywords_false["is_evspd"], keywords_fall["is_evspd"], threshold = 0.9)
			if is_evspd:
				request_data["main_work"]['is_evspd'] = answer_yes_no(is_evspd.lower())
				#print(f'ЕВСПД = {answer_yes_no(is_evspd.lower())}')
		
		data = {"requests": [request_data]}
		
	return data
